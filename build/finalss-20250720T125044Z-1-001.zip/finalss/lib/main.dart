import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lipa LGU Assets',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        colorScheme: ColorScheme.light(
          primary: Color(0xFF2E7D32),
          secondary: Color(0xFF66BB6A),
          surface: Colors.white,
          background: Color(0xFFF5F5F5),
        ),
        appBarTheme: AppBarTheme(
          elevation: 0,
          centerTitle: true,
          backgroundColor: Color(0xFF2E7D32),
          iconTheme: IconThemeData(color: Colors.white),
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            
            padding: EdgeInsets.symmetric(vertical: 14, horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 3,
            textStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
              textStyle: TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
      home: StartScreen(),
    );
  }
}

class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo 
                Container(
                  width: 160,
                  height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(
                      color: Color(0xFF2E7D32),
                      width: 3,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 12,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/lipa_logo.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => 
                        Icon(Icons.photo_camera, size: 60, color: Color(0xFF2E7D32)),
                    ),
                  ),
                ),
                SizedBox(height: 32),
                Text(
                  'Lipa LGU IT',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1B5E20),
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Assets Management App ',
                  style: TextStyle(
                    fontSize: 20,
                    color: Color(0xFF2E7D32),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    'Comprehensive tracking system for government IT assets and equipment',
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF4CAF50),
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => OfficesDepartmentsScreen()),
                    );
                  },
                  child: Text(
                    'GET STARTED',
                    style: TextStyle(fontSize: 18, letterSpacing: 0.5),
                  ),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                    elevation: 5,
                    shadowColor: Color(0xFF2E7D32).withOpacity(0.3),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class OfficesDepartmentsScreen extends StatelessWidget {
  final List<String> departments = [
    "Mayor's Office",
    "Vice-Mayor's Office",
    "Administrator's Office",
    "Environment & Natural Resources",
    "Social Welfare & Development",
    "General Services Office",
    "Treasurer's Office",
    "Assessor's Office",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Department'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: GridView.builder(
          padding: EdgeInsets.all(16),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            childAspectRatio: 1.1,
          ),
          itemCount: departments.length,
          itemBuilder: (context, index) {
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 3,
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AdminLoginScreen(departments[index]),
                    ),
                  );
                },
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Color(0xFFE8F5E9),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.apartment_rounded,
                          color: Color(0xFF2E7D32),
                          size: 28,
                        ),
                      ),
                      SizedBox(height: 12),
                      Text(
                        departments[index],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1B5E20),
                          fontSize: 14,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class AdminLoginScreen extends StatelessWidget {
  final String department;
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  AdminLoginScreen(this.department);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Login'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: Color(0xFFE8F5E9),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.admin_panel_settings_rounded,
                            size: 40,
                            color: Color(0xFF2E7D32),
                          ),
                        ),
                        SizedBox(height: 16),
                        Text(
                          department,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1B5E20),
                          ),
                        ),
                        SizedBox(height: 24),
                        TextField(
                          controller: usernameController,
                          decoration: InputDecoration(
                            labelText: 'Username',
                            prefixIcon: Icon(Icons.person_outline),
                            contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                          ),
                        ),
                        SizedBox(height: 16),
                        TextField(
                          controller: passwordController,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Password',
                            prefixIcon: Icon(Icons.lock_outline),
                            contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                          ),
                        ),
                        SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (usernameController.text == 'admin' &&
                                  passwordController.text == 'admin123') {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        AdminDashboard(department),
                                  ),
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Invalid Admin Credentials'),
                                    backgroundColor: Colors.red,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                );
                              }
                            },
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: Text(
                                'LOGIN AS ADMIN',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    UserLoginScreen(department),
                              ),
                            );
                          },
                          child: Text('Switch to USER LOGIN'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class UserLoginScreen extends StatelessWidget {
  final String department;
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  UserLoginScreen(this.department);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Login'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: Color(0xFFE8F5E9),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.person_rounded,
                            size: 40,
                            color: Color(0xFF2E7D32),
                          ),
                        ),
                        SizedBox(height: 16),
                        Text(
                          department,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1B5E20),
                          ),
                        ),
                        SizedBox(height: 24),
                        TextField(
                          controller: usernameController,
                          decoration: InputDecoration(
                            labelText: 'Username',
                            prefixIcon: Icon(Icons.person_outline),
                            contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                          ),
                        ),
                        SizedBox(height: 16),
                        TextField(
                          controller: passwordController,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Password',
                            prefixIcon: Icon(Icons.lock_outline),
                            contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                          ),
                        ),
                        SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (usernameController.text == 'user' &&
                                  passwordController.text == 'user123') {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        UserDashboard(department),
                                  ),
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Invalid User Credentials'),
                                    backgroundColor: Colors.red,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                );
                              }
                            },
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: Text(
                                'LOGIN AS USER',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    AdminLoginScreen(department),
                              ),
                            );
                          },
                          child: Text('Switch to ADMIN LOGIN'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AdminDashboard extends StatelessWidget {
  final String department;
  AdminDashboard(this.department);
  @override
  Widget build(BuildContext context) => DashboardScreen(
        title: 'Admin Dashboard',
        welcomeMessage: 'Welcome, Admin!',
        department: department,
        isAdmin: true,
      );
}

class UserDashboard extends StatelessWidget {
  final String department;
  UserDashboard(this.department);
  @override
  Widget build(BuildContext context) => DashboardScreen(
        title: 'User Dashboard',
        welcomeMessage: 'Welcome, User!',
        department: department,
        isAdmin: false,
      );
}

class DashboardScreen extends StatelessWidget {
  final String title;
  final String welcomeMessage;
  final String department;
  final bool isAdmin;

  DashboardScreen({
    required this.title,
    required this.welcomeMessage,
    required this.department,
    required this.isAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              Navigator.popUntil(context, (route) => route.isFirst);
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Color(0xFFE8F5E9),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            department.length >= 2
                                ? department.substring(0, 2).toUpperCase()
                                : "LGU",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF2E7D32),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        welcomeMessage,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1B5E20),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        department,
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF2E7D32),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: [
                    _buildDashboardOption(
                      context,
                      'Hardware Tracking',
                      Icons.computer_rounded,
                      HardwarePage(),
                    ),
                    _buildDashboardOption(
                      context,
                      'Software Tracking',
                      Icons.install_desktop_rounded,
                      SoftwarePage(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDashboardOption(
      BuildContext context, String title, IconData icon, Widget page) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Color(0xFFE8F5E9),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Color(0xFF2E7D32), size: 20),
        ),
        title: Text(
          title,
          style: TextStyle(fontWeight: FontWeight.w500),
        ),
        trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => page));
        },
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}

class HardwarePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => _buildListPage(
        context,
        'Hardware',
        ['PCs', 'Printers', 'Laptops', 'Tablets', 'Routers', 'Monitors', 'Servers', 'Switches', 'Access Points'],
      );
}

class SoftwarePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => _buildListPage(
        context,
        'Software',
        ['Windows OS', 'Antivirus', 'Office Suite', 'Database Systems'],
      );
}

Widget _buildListPage(BuildContext context, String title, List<String> items) {
  return Scaffold(
    appBar: AppBar(
      title: Text('$title Tracking'),
    ),
    body: Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFE8F5E9),
            Color(0xFFC8E6C9),
          ],
        ),
      ),
      child: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Color(0xFFE8F5E9),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getIconForCategory(items[index]),
                  color: Color(0xFF2E7D32),
                  size: 20,
                ),
              ),
              title: Text(
                items[index],
                style: TextStyle(fontWeight: FontWeight.w500),
              ),
              trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ItemListPage(items[index]),
                  ),
                );
              },
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          );
        },
      ),
    ),
  );
}

IconData _getIconForCategory(String category) {
  switch (category) {
    case 'PCs':
      return Icons.computer_rounded;
    case 'Printers':
      return Icons.print_rounded;
    case 'Laptops':
      return Icons.laptop_rounded;
    case 'Tablets':
      return Icons.tablet_android_rounded;
    case 'Routers':
      return Icons.router_rounded;
    case 'Monitors':
      return Icons.desktop_windows_rounded;
    case 'Servers':
      return Icons.storage_rounded;
    case 'Switches':
      return Icons.lan_rounded;
    case 'Access Points':
      return Icons.network_wifi_rounded;
    case 'Windows OS':
      return Icons.window_rounded;
    case 'Antivirus':
      return Icons.security_rounded;
    case 'Office Suite':
      return Icons.description_rounded;
    case 'Database Systems':
      return Icons.storage_rounded;
    default:
      return Icons.device_unknown_rounded;
  }
}

class ItemListPage extends StatelessWidget {
  final String category;
  ItemListPage(this.category);

  final Map<String, List<String>> itemsMap = {
    'PCs': ['PC-0001', 'PC-0002', 'PC-0003', 'PC-0004', 'PC-0005', 'PC-0006', 'PC-0007', 'PC-0008'],
    'Printers': ['PR-0001', 'PR-0002', 'PR-0003', 'PR-0004', 'PR-0005'],
    'Laptops': ['LP-0001', 'LP-0002', 'LP-0003', 'LP-0004', 'LP-0005', 'LP-0006'],
    'Tablets': ['TB-0001', 'TB-0002', 'TB-0003', 'TB-0004'],
    'Routers': ['RT-0001', 'RT-0002', 'RT-0003', 'RT-0004', 'RT-0005'],
    'Monitors': ['MN-0001', 'MN-0002', 'MN-0003', 'MN-0004', 'MN-0005', 'MN-0006'],
    'Servers': ['SV-0001', 'SV-0002', 'SV-0003'],
    'Switches': ['SW-0001', 'SW-0002', 'SW-0003', 'SW-0004'],
    'Access Points': ['AP-0001', 'AP-0002', 'AP-0003', 'AP-0004', 'AP-0005'],
    'Windows OS': ['WIN10-001', 'WIN11-001', 'WIN10-002', 'WIN11-002', 'WIN10-003'],
    'Antivirus': ['AV-0001', 'AV-0002', 'AV-0003', 'AV-0004', 'AV-0005'],
    'Office Suite': ['OFF-0001', 'OFF-0002', 'OFF-0003', 'OFF-0004'],
    'Database Systems': ['DB-0001', 'DB-0002'],
  };

  @override
  Widget build(BuildContext context) {
    final items = itemsMap[category] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text(category),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: items.length,
          itemBuilder: (context, index) {
            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Color(0xFFE8F5E9),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _getIconForCategory(category),
                    color: Color(0xFF2E7D32),
                    size: 20,
                  ),
                ),
                title: Text(
                  items[index],
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                subtitle: Text('${category} Asset'),
                trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ItemDetailPage(items[index]),
                    ),
                  );
                },
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ItemDetailPage extends StatelessWidget {
  final String itemId;

  ItemDetailPage(this.itemId);

  final Map<String, Map<String, String>> inventoryDatabase = {
    'PC-0001': {
      'name': 'PC-0001',
      'type': 'Desktop Computer',
      'model': 'HP ProDesk 400 G7',
      'serial': 'HP-123456789',
      'date': 'March 5, 2024',
      'cost': '₱35,000',
      'user': 'Mark Ronquillo',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Office workstation'
    },
    'PC-0002': {
      'name': 'PC-0002',
      'type': 'Desktop Computer',
      'model': 'HP ProDesk 400 G7',
      'serial': 'HP-234567891',
      'date': 'March 5, 2024',
      'cost': '₱35,000',
      'user': 'Neil Baes',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Office workstation'
    },
    'PC-0003': {
      'name': 'PC-0003',
      'type': 'Desktop Computer',
      'model': 'HP ProDesk 400 G7',
      'serial': 'HP-345678912',
      'date': 'March 5, 2024',
      'cost': '₱35,000',
      'user': 'Gian Estipona',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Office workstation'
    },
    'PC-0004': {
      'name': 'PC-0004',
      'type': 'Desktop Computer',
      'model': 'Dell OptiPlex 3080',
      'serial': 'DL-987654321',
      'date': 'April 10, 2024',
      'cost': '₱38,000',
      'user': 'John Doe',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': 'Main office computer'
    },
    'PC-0005': {
      'name': 'PC-0005',
      'type': 'Desktop Computer',
      'model': 'Lenovo ThinkCentre M90n',
      'serial': 'LN-567891234',
      'date': 'May 15, 2024',
      'cost': '₱40,000',
      'user': 'Jane Smith',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'Compact desktop unit'
    },
    'PC-0006': {
      'name': 'PC-0006',
      'type': 'Desktop Computer',
      'model': 'Acer Veriton N4660G',
      'serial': 'AC-123789456',
      'date': 'June 20, 2024',
      'cost': '₱32,000',
      'user': 'Shared',
      'location': "Treasurer's Office",
      'status': 'In Use',
      'notes': 'Shared workstation'
    },
    'PC-0007': {
      'name': 'PC-0007',
      'type': 'Desktop Computer',
      'model': 'Asus ExpertCenter D500SA',
      'serial': 'AS-456123789',
      'date': 'July 5, 2024',
      'cost': '₱36,500',
      'user': 'Shared',
      'location': "Assessor's Office",
      'status': 'In Use',
      'notes': 'Public access computer'
    },
    'PC-0008': {
      'name': 'PC-0008',
      'type': 'Desktop Computer',
      'model': 'HP EliteDesk 800 G6',
      'serial': 'HP-789456123',
      'date': 'August 12, 2024',
      'cost': '₱42,000',
      'user': 'Department Head',
      'location': "Social Welfare & Development",
      'status': 'In Use',
      'notes': 'Manager workstation'
    },
    'PR-0001': {
      'name': 'PR-0001',
      'type': 'Laser Printer',
      'model': 'HP LaserJet Pro M404dn',
      'serial': 'HP-PRT-123456',
      'date': 'March 8, 2024',
      'cost': '₱15,000',
      'user': 'Shared',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Main office printer'
    },
    'PR-0002': {
      'name': 'PR-0002',
      'type': 'Multifunction Printer',
      'model': 'Brother MFC-L3750CDW',
      'serial': 'BR-PRT-789456',
      'date': 'April 5, 2024',
      'cost': '₱18,000',
      'user': 'Shared',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'Color laser printer'
    },
    'PR-0003': {
      'name': 'PR-0003',
      'type': 'Inkjet Printer',
      'model': 'Epson L3110',
      'serial': 'EP-PRT-456123',
      'date': 'May 10, 2024',
      'cost': '₱8,500',
      'user': 'Shared',
      'location': "General Services Office",
      'status': 'In Use',
      'notes': 'General purpose printing'
    },
    'PR-0004': {
      'name': 'PR-0004',
      'type': 'Laser Printer',
      'model': 'Canon imageCLASS LBP6230dw',
      'serial': 'CN-PRT-123789',
      'date': 'June 15, 2024',
      'cost': '₱16,500',
      'user': 'Shared',
      'location': "Treasurer's Office",
      'status': 'In Use',
      'notes': 'High-volume printing'
    },
    'PR-0005': {
      'name': 'PR-0005',
      'type': 'Dot Matrix Printer',
      'model': 'Epson LQ-310',
      'serial': 'EP-PRT-789123',
      'date': 'July 20, 2024',
      'cost': '₱12,000',
      'user': 'Shared',
      'location': "Assessor's Office",
      'status': 'In Use',
      'notes': 'For official receipts'
    },
    'LP-0001': {
      'name': 'LP-0001',
      'type': 'Laptop',
      'model': 'Dell Latitude 5420',
      'serial': 'DLL-123456',
      'date': 'March 10, 2024',
      'cost': '₱45,000',
      'user': 'Department Head',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'For mobile work'
    },
    'LP-0002': {
      'name': 'LP-0002',
      'type': 'Laptop',
      'model': 'HP EliteBook 840 G8',
      'serial': 'HP-LPT-456789',
      'date': 'April 12, 2024',
      'cost': '₱48,000',
      'user': 'Department Head',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': 'Executive laptop'
    },
    'LP-0003': {
      'name': 'LP-0003',
      'type': 'Laptop',
      'model': 'Lenovo ThinkPad T14',
      'serial': 'LN-LPT-789123',
      'date': 'May 18, 2024',
      'cost': '₱42,000',
      'user': 'IT Staff',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'IT support laptop'
    },
    'LP-0004': {
      'name': 'LP-0004',
      'type': 'Laptop',
      'model': 'Asus ExpertBook B9',
      'serial': 'AS-LPT-123456',
      'date': 'June 22, 2024',
      'cost': '₱50,000',
      'user': 'Department Head',
      'location': "Social Welfare & Development",
      'status': 'In Use',
      'notes': 'Lightweight business laptop'
    },
    'LP-0005': {
      'name': 'LP-0005',
      'type': 'Laptop',
      'model': 'Acer TravelMate P4',
      'serial': 'AC-LPT-456123',
      'date': 'July 25, 2024',
      'cost': '₱38,000',
      'user': 'Field Officer',
      'location': "Environment & Natural Resources",
      'status': 'In Use',
      'notes': 'Field work laptop'
    },
    'LP-0006': {
      'name': 'LP-0006',
      'type': 'Laptop',
      'model': 'MacBook Air M1',
      'serial': 'AP-LPT-789456',
      'date': 'August 5, 2024',
      'cost': '₱55,000',
      'user': 'IT Manager',
      'location': "General Services Office",
      'status': 'In Use',
      'notes': 'For graphic design work'
    },
    'TB-0001': {
      'name': 'TB-0001',
      'type': 'Tablet',
      'model': 'iPad Air (4th Gen)',
      'serial': 'AP-TAB-123456',
      'date': 'April 15, 2024',
      'cost': '₱35,000',
      'user': 'Department Head',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'For presentations'
    },
    'TB-0002': {
      'name': 'TB-0002',
      'type': 'Tablet',
      'model': 'Samsung Galaxy Tab S7',
      'serial': 'SS-TAB-456789',
      'date': 'May 20, 2024',
      'cost': '₱30,000',
      'user': 'Field Officer',
      'location': "Environment & Natural Resources",
      'status': 'In Use',
      'notes': 'Field data collection'
    },
    'TB-0003': {
      'name': 'TB-0003',
      'type': 'Tablet',
      'model': 'Microsoft Surface Go 3',
      'serial': 'MS-TAB-789123',
      'date': 'June 25, 2024',
      'cost': '₱28,000',
      'user': 'IT Staff',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'IT support tablet'
    },
    'TB-0004': {
      'name': 'TB-0004',
      'type': 'Tablet',
      'model': 'Lenovo Tab P11 Pro',
      'serial': 'LN-TAB-123789',
      'date': 'July 30, 2024',
      'cost': '₱25,000',
      'user': 'Shared',
      'location': "Social Welfare & Development",
      'status': 'In Use',
      'notes': 'Client registration'
    },
    'RT-0001': {
      'name': 'RT-0001',
      'type': 'Router',
      'model': 'Cisco ISR 1100',
      'serial': 'CS-RTR-123456',
      'date': 'March 12, 2024',
      'cost': '₱25,000',
      'user': 'IT Department',
      'location': "Main Server Room",
      'status': 'In Use',
      'notes': 'Main office router'
    },
    'RT-0002': {
      'name': 'RT-0002',
      'type': 'Router',
      'model': 'TP-Link ER605',
      'serial': 'TP-RTR-456789',
      'date': 'April 18, 2024',
      'cost': '₱12,000',
      'user': 'IT Department',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Department router'
    },
    'RT-0003': {
      'name': 'RT-0003',
      'type': 'Router',
      'model': 'Ubiquiti EdgeRouter X',
      'serial': 'UB-RTR-789123',
      'date': 'May 22, 2024',
      'cost': '₱8,000',
      'user': 'IT Department',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': 'Department router'
    },
    'RT-0004': {
      'name': 'RT-0004',
      'type': 'Router',
      'model': 'MikroTik hEX',
      'serial': 'MT-RTR-123789',
      'date': 'June 28, 2024',
      'cost': '₱10,000',
      'user': 'IT Department',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'Department router'
    },
    'RT-0005': {
      'name': 'RT-0005',
      'type': 'Wireless Router',
      'model': 'Asus RT-AX86U',
      'serial': 'AS-RTR-456123',
      'date': 'July 5, 2024',
      'cost': '₱15,000',
      'user': 'IT Department',
      'location': "Conference Room",
      'status': 'In Use',
      'notes': 'For meetings and events'
    },
    'MN-0001': {
      'name': 'MN-0001',
      'type': 'Monitor',
      'model': 'Dell P2422H',
      'serial': 'DL-MON-123456',
      'date': 'March 15, 2024',
      'cost': '₱12,000',
      'user': 'Mark Ronquillo',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': '24-inch Full HD'
    },
    'MN-0002': {
      'name': 'MN-0002',
      'type': 'Monitor',
      'model': 'HP M24f FHD',
      'serial': 'HP-MON-456789',
      'date': 'April 20, 2024',
      'cost': '₱11,500',
      'user': 'Neil Baes',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': '23.8-inch Full HD'
    },
    'MN-0003': {
      'name': 'MN-0003',
      'type': 'Monitor',
      'model': 'Acer Nitro VG240Y',
      'serial': 'AC-MON-789123',
      'date': 'May 25, 2024',
      'cost': '₱13,000',
      'user': 'Gian Estipona',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': '24-inch IPS Full HD'
    },
    'MN-0004': {
      'name': 'MN-0004',
      'type': 'Monitor',
      'model': 'LG 27QN600-B',
      'serial': 'LG-MON-123789',
      'date': 'June 30, 2024',
      'cost': '₱15,000',
      'user': 'John Doe',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': '27-inch QHD IPS'
    },
    'MN-0005': {
      'name': 'MN-0005',
      'type': 'Monitor',
      'model': 'Samsung S24R350',
      'serial': 'SS-MON-456123',
      'date': 'July 8, 2024',
      'cost': '₱12,500',
      'user': 'Jane Smith',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': '24-inch IPS'
    },
    'MN-0006': {
      'name': 'MN-0006',
      'type': 'Monitor',
      'model': 'Asus ProArt PA278QV',
      'serial': 'AS-MON-789456',
      'date': 'August 10, 2024',
      'cost': '₱20,000',
      'user': 'IT Manager',
      'location': "General Services Office",
      'status': 'In Use',
      'notes': '27-inch WQHD'
    },
    'SV-0001': {
      'name': 'SV-0001',
      'type': 'Server',
      'model': 'Dell PowerEdge R750',
      'serial': 'DL-SVR-123456',
      'date': 'March 18, 2024',
      'cost': '₱250,000',
      'user': 'IT Department',
      'location': "Main Server Room",
      'status': 'In Use',
      'notes': 'Primary database server'
    },
    'SV-0002': {
      'name': 'SV-0002',
      'type': 'Server',
      'model': 'HP ProLiant DL380 Gen10',
      'serial': 'HP-SVR-456789',
      'date': 'April 22, 2024',
      'cost': '₱220,000',
      'user': 'IT Department',
      'location': "Main Server Room",
      'status': 'In Use',
      'notes': 'File and print server'
    },
    'SV-0003': {
      'name': 'SV-0003',
      'type': 'Server',
      'model': 'Lenovo ThinkSystem SR650',
      'serial': 'LN-SVR-789123',
      'date': 'May 28, 2024',
      'cost': '₱230,000',
      'user': 'IT Department',
      'location': "Backup Server Room",
      'status': 'In Use',
      'notes': 'Backup server'
    },
    'SW-0001': {
      'name': 'SW-0001',
      'type': 'Network Switch',
      'model': 'Cisco Catalyst 2960-X',
      'serial': 'CS-SW-123456',
      'date': 'March 20, 2024',
      'cost': '₱50,000',
      'user': 'IT Department',
      'location': "Main Server Room",
      'status': 'In Use',
      'notes': 'Core switch'
    },
    'SW-0002': {
      'name': 'SW-0002',
      'type': 'Network Switch',
      'model': 'HP Aruba 2530',
      'serial': 'HP-SW-456789',
      'date': 'April 25, 2024',
      'cost': '₱35,000',
      'user': 'IT Department',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Department switch'
    },
    'SW-0003': {
      'name': 'SW-0003',
      'type': 'Network Switch',
      'model': 'Ubiquiti USW-24-PoE',
      'serial': 'UB-SW-789123',
      'date': 'May 30, 2024',
      'cost': '₱40,000',
      'user': 'IT Department',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'PoE switch for phones'
    },
    'SW-0004': {
      'name': 'SW-0004',
      'type': 'Network Switch',
      'model': 'Netgear GS724T',
      'serial': 'NT-SW-123789',
      'date': 'June 5, 2024',
      'cost': '₱25,000',
      'user': 'IT Department',
      'location': "Social Welfare & Development",
      'status': 'In Use',
      'notes': 'Department switch'
    },
    'AP-0001': {
      'name': 'AP-0001',
      'type': 'Wireless Access Point',
      'model': 'Ubiquiti UAP-AC-PRO',
      'serial': 'UB-AP-123456',
      'date': 'March 22, 2024',
      'cost': '₱12,000',
      'user': 'IT Department',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'Main office WiFi'
    },
    'AP-0002': {
      'name': 'AP-0002',
      'type': 'Wireless Access Point',
      'model': 'Cisco WAP581',
      'serial': 'CS-AP-456789',
      'date': 'April 28, 2024',
      'cost': '₱15,000',
      'user': 'IT Department',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': 'Department WiFi'
    },
    'AP-0003': {
      'name': 'AP-0003',
      'type': 'Wireless Access Point',
      'model': 'TP-Link EAP245',
      'serial': 'TP-AP-789123',
      'date': 'June 2, 2024',
      'cost': '₱10,000',
      'user': 'IT Department',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'Department WiFi'
    },
    'AP-0004': {
      'name': 'AP-0004',
      'type': 'Wireless Access Point',
      'model': 'Aruba Instant On AP22',
      'serial': 'AR-AP-123789',
      'date': 'July 10, 2024',
      'cost': '₱13,000',
      'user': 'IT Department',
      'location': "Conference Room",
      'status': 'In Use',
      'notes': 'High-density WiFi'
    },
    'AP-0005': {
      'name': 'AP-0005',
      'type': 'Wireless Access Point',
      'model': 'Ruckus R550',
      'serial': 'RK-AP-456123',
      'date': 'August 15, 2024',
      'cost': '₱20,000',
      'user': 'IT Department',
      'location': "Lobby Area",
      'status': 'In Use',
      'notes': 'Public access WiFi'
    },
    'WIN10-001': {
      'name': 'WIN10-001',
      'type': 'Operating System',
      'model': 'Windows 10 Pro',
      'serial': 'MS-WIN-123456',
      'date': 'March 5, 2024',
      'cost': '₱8,000',
      'user': 'Mark Ronquillo',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'PC-0001 license'
    },
    'WIN10-002': {
      'name': 'WIN10-002',
      'type': 'Operating System',
      'model': 'Windows 10 Pro',
      'serial': 'MS-WIN-234567',
      'date': 'March 5, 2024',
      'cost': '₱8,000',
      'user': 'Neil Baes',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'PC-0002 license'
    },
    'WIN10-003': {
      'name': 'WIN10-003',
      'type': 'Operating System',
      'model': 'Windows 10 Pro',
      'serial': 'MS-WIN-345678',
      'date': 'March 5, 2024',
      'cost': '₱8,000',
      'user': 'Gian Estipona',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': 'PC-0003 license'
    },
    'WIN11-001': {
      'name': 'WIN11-001',
      'type': 'Operating System',
      'model': 'Windows 11 Pro',
      'serial': 'MS-WIN-456789',
      'date': 'April 10, 2024',
      'cost': '₱9,000',
      'user': 'John Doe',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': 'PC-0004 license'
    },
    'WIN11-002': {
      'name': 'WIN11-002',
      'type': 'Operating System',
      'model': 'Windows 11 Pro',
      'serial': 'MS-WIN-567890',
      'date': 'May 15, 2024',
      'cost': '₱9,000',
      'user': 'Jane Smith',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': 'PC-0005 license'
    },
    'AV-0001': {
      'name': 'AV-0001',
      'type': 'Antivirus',
      'model': 'Kaspersky Endpoint Security',
      'serial': 'KAV-123456',
      'date': 'March 1, 2024',
      'cost': '₱5,000',
      'user': 'IT Department',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': '50-user license'
    },
    'AV-0002': {
      'name': 'AV-0002',
      'type': 'Antivirus',
      'model': 'ESET Endpoint Protection',
      'serial': 'ESET-234567',
      'date': 'April 1, 2024',
      'cost': '₱4,500',
      'user': 'IT Department',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': '25-user license'
    },
    'AV-0003': {
      'name': 'AV-0003',
      'type': 'Antivirus',
      'model': 'Symantec Endpoint Protection',
      'serial': 'SYM-345678',
      'date': 'May 1, 2024',
      'cost': '₱6,000',
      'user': 'IT Department',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': '30-user license'
    },
    'AV-0004': {
      'name': 'AV-0004',
      'type': 'Antivirus',
      'model': 'Bitdefender GravityZone',
      'serial': 'BIT-456789',
      'date': 'June 1, 2024',
      'cost': '₱5,500',
      'user': 'IT Department',
      'location': "General Services Office",
      'status': 'In Use',
      'notes': '40-user license'
    },
    'AV-0005': {
      'name': 'AV-0005',
      'type': 'Antivirus',
      'model': 'Trend Micro Worry-Free',
      'serial': 'TREND-567890',
      'date': 'July 1, 2024',
      'cost': '₱4,800',
      'user': 'IT Department',
      'location': "Treasurer's Office",
      'status': 'In Use',
      'notes': '20-user license'
    },
    'OFF-0001': {
      'name': 'OFF-0001',
      'type': 'Office Suite',
      'model': 'Microsoft 365 Business',
      'serial': 'MS-OFF-123456',
      'date': 'March 1, 2024',
      'cost': '₱12,000',
      'user': 'IT Department',
      'location': "Mayor's Office",
      'status': 'In Use',
      'notes': '50-user annual subscription'
    },
    'OFF-0002': {
      'name': 'OFF-0002',
      'type': 'Office Suite',
      'model': 'Microsoft 365 Business',
      'serial': 'MS-OFF-234567',
      'date': 'April 1, 2024',
      'cost': '₱12,000',
      'user': 'IT Department',
      'location': "Vice-Mayor's Office",
      'status': 'In Use',
      'notes': '50-user annual subscription'
    },
    'OFF-0003': {
      'name': 'OFF-0003',
      'type': 'Office Suite',
      'model': 'LibreOffice',
      'serial': 'LIBRE-345678',
      'date': 'May 1, 2024',
      'cost': '₱0',
      'user': 'IT Department',
      'location': "General Services Office",
      'status': 'In Use',
      'notes': 'Open-source office suite'
    },
    'OFF-0004': {
      'name': 'OFF-0004',
      'type': 'Office Suite',
      'model': 'Google Workspace',
      'serial': 'GOOG-456789',
      'date': 'June 1, 2024',
      'cost': '₱10,000',
      'user': 'IT Department',
      'location': "Administrator's Office",
      'status': 'In Use',
      'notes': '30-user annual subscription'
    },
    'DB-0001': {
      'name': 'DB-0001',
      'type': 'Database System',
      'model': 'Microsoft SQL Server',
      'serial': 'MS-SQL-123456',
      'date': 'March 15, 2024',
      'cost': '₱50,000',
      'user': 'IT Department',
      'location': "Main Server Room",
      'status': 'In Use',
      'notes': 'Enterprise edition'
    },
    'DB-0002': {
      'name': 'DB-0002',
      'type': 'Database System',
      'model': 'MySQL Enterprise',
      'serial': 'MYSQL-234567',
      'date': 'April 15, 2024',
      'cost': '₱25,000',
      'user': 'IT Department',
      'location': "Backup Server Room",
      'status': 'In Use',
      'notes': 'Annual subscription'
    },
  };

  @override
  Widget build(BuildContext context) {
    final itemData = inventoryDatabase[itemId] ?? {
      'name': itemId,
      'type': 'Unknown',
      'model': 'N/A',
      'serial': 'N/A',
      'date': 'Unknown',
      'cost': 'N/A',
      'user': 'Unassigned',
      'location': 'Unknown',
      'status': 'Unknown',
      'notes': 'No information available'
    };

    return Scaffold(
      appBar: AppBar(
        title: Text('${itemData['type']} Details'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE8F5E9),
              Color(0xFFC8E6C9),
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Color(0xFFE8F5E9),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.inventory_rounded,
                          size: 40,
                          color: Color(0xFF2E7D32),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        itemData['name']!,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1B5E20),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        itemData['model']!,
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFF2E7D32),
                        ),
                      ),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDetailRow('Asset ID', itemData['name']!),
                      _buildDetailRow('Type', itemData['type']!),
                      _buildDetailRow('Model', itemData['model']!),
                      _buildDetailRow('Serial Number', itemData['serial']!),
                      _buildDetailRow('Purchase Date', itemData['date']!),
                      _buildDetailRow('Purchase Cost', itemData['cost']!),
                      _buildDetailRow(
                          'Assigned To', itemData['user']!, isHighlighted: true),
                      _buildDetailRow(
                          'Location', itemData['location']!, isHighlighted: true),
                      _buildDetailRow(
                          'Status', itemData['status']!, isHighlighted: true),
                      SizedBox(height: 16),
                      Text(
                        'Additional Notes:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1B5E20),
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Color(0xFFE8F5E9),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          itemData['notes']!,
                          style: TextStyle(
                            color: Colors.grey[800],
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value,
      {bool isHighlighted = false}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isHighlighted ? Color(0xFF1B5E20) : Colors.grey[700],
              ),
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: isHighlighted ? Color(0xFF1B5E20) : Colors.black87,
                fontSize: isHighlighted ? 16 : 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}