package com.example.finalss

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
